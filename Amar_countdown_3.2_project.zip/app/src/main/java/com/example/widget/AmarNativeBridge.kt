package com.example.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.webkit.JavascriptInterface

/** Exposed to the web app as `window.AmarNative`. */
class AmarNativeBridge(private val context: Context) {

    /** Called by the web app whenever events / language / theme change. */
    @JavascriptInterface
    fun syncEvents(json: String) {
        WidgetData.save(context, json)
        CountdownWidgetProvider.refreshAll(context)
    }

    /** Asks Android to show the "Add widget to home screen" dialog. Returns "requested" or "unsupported". */
    @JavascriptInterface
    fun requestPinWidget(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return "unsupported"
        val mgr = context.getSystemService(AppWidgetManager::class.java) ?: return "unsupported"
        if (!mgr.isRequestPinAppWidgetSupported) return "unsupported"
        val ok = mgr.requestPinAppWidget(ComponentName(context, CountdownWidgetProvider::class.java), null, null)
        return if (ok) "requested" else "unsupported"
    }

    @JavascriptInterface
    fun isWidgetSupported(): Boolean = true
}
